from setuptools import setup

setup(
	name='SRHpylibs',
	version='0.1',
	py_modules=['SRHpylibs'],
	install_requires=[
		'colored'
	],
)
